from Scraping.scraping_P import *
